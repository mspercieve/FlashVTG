import torch
import torch.nn as nn
import torch.nn.functional as F
import sys
sys.path.append('utils/')
import net_utils
import math
from .position_encoding import PositionEmbeddingSine
from einops import rearrange, repeat
from natten.functional import natten2dqkrpb, natten2dav
from .transformer import TransformerEncoderLayer, TransformerEncoder

class Attention(nn.Module):
    def __init__(self, kdim, cdim, hdim, drop_p):
        super(Attention, self).__init__()
        att_hdim = hdim
        # layers
        self.key2att = nn.Linear(kdim, att_hdim)
        self.feat2att = nn.Linear(cdim, att_hdim)
        self.to_alpha = nn.Linear(att_hdim, 1)
        self.drop = nn.Dropout(drop_p)

    def forward(self, key, feats, feat_masks=None, return_weight=True):
        """ Compute attention weights and attended feature (weighted sum)
        Args:
            key: key vector to compute attention weights; [B, K]
            feats: features where attention weights are computed; [B, A, D]
            feat_masks: mask for effective features; [B, A]
        """
        # check inputs
        assert len(key.size()) == 2, "{} != 2".format(len(key.size()))
        assert len(feats.size()) == 3 or len(feats.size()) == 4
        assert feat_masks is None or len(feat_masks.size()) == 2

        # dealing with dnsion 4
        if len(feats.size()) == 4:
            B, W, H, D = feats.size()
            feats = feats.view(B, W*H, D)

        # compute attention weights
        logits = self.compute_att_logits(key, feats, feat_masks) # [B,A]
        weight = self.drop(F.softmax(logits, dim=1))             # [B,A]

        # compute weighted sum: bmm working on (B,1,A) * (B,A,D) -> (B,1,D)
        att_feats = torch.bmm(weight.unsqueeze(1), feats).squeeze(1) # B * D
        if return_weight:
            return att_feats, weight
        return att_feats

    def compute_att_logits(self, key, feats, feat_masks=None):
        """ Compute attention weights
        Args:
            key: key vector to compute attention weights; [B, K]
            feats: features where attention weights are computed; [B, A, D]
            feat_masks: mask for effective features; [B, A]
        """
        # check inputs
        assert len(key.size()) == 2
        assert len(feats.size()) == 3 or len(feats.size()) == 4
        assert feat_masks is None or len(feat_masks.size()) == 2

        # dealing with dnsion 4
        if len(feats.size()) == 4:
            B, W, H, D = feats.size()
            feats = feats.view(B, W*H, D)
        A = feats.size(1)

        # embedding key and feature vectors
        att_f = net_utils.apply_on_sequence(self.feat2att, feats)   # B * A * att_hdim
        att_k = self.key2att(key)                                   # B * att_hdim
        att_k = att_k.unsqueeze(1).expand_as(att_f)                 # B * A * att_hdim

        # compute attention weights
        dot = torch.tanh(att_f + att_k)                             # B * A * att_hdim
        alpha = net_utils.apply_on_sequence(self.to_alpha, dot)     # B * A * 1
        alpha = alpha.view(-1, A)                                   # B * A
        if feat_masks is not None:
            alpha = alpha.masked_fill(feat_masks.float().eq(0), -1e9)

        return alpha


class CrossAttention(nn.Module):
    def __init__(self, hdim, nheads, dropout=0.1):
        super(CrossAttention, self).__init__()
        self.hdim = hdim
        self.nheads = nheads
        self.att = nn.MultiheadAttention(hdim, nheads, batch_first=True, dropout=dropout)
        self.q_proj = nn.Linear(hdim, hdim)
        self.k_proj = nn.Linear(hdim, hdim)
        self.v_proj = nn.Linear(hdim, hdim)
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(hdim)
        
        self.ffn = nn.Sequential(
            nn.Linear(hdim, hdim*4),
            nn.ReLU(),
            nn.Linear(hdim*4, hdim),
            nn.Dropout(dropout)
        )

    def forward(self, x, y, mask=None):
        """
        Args:
            x: [B, L, C] - query
            y: [B, L, C] - key/value
            mask: [B, L]
        Returns:
            output: [B, L, C]
            attn_weights: [B, L, L]
        """
        q = self.q_proj(x)
        k = self.k_proj(y)
        v = self.v_proj(y)

        if mask is not None:
            output, attn_weights = self.att(q, k, v, key_padding_mask=~(mask.bool()))
        else:
            output, attn_weights = self.att(q, k, v)
            
        output = self.dropout(output)
        output = self.norm(output + x)
        output = self.ffn(output) + output
        return output, attn_weights


class SequentialQueryAttention(nn.Module):
    def __init__(self, num_phrase, qdim):
        super(SequentialQueryAttention, self).__init__()

        self.nse = num_phrase
        self.qdim = qdim # 512
        self.global_emb_fn = nn.ModuleList( # W_q^(n) in Eq. (4)
                [nn.Linear(self.qdim, self.qdim) for i in range(self.nse)])
        self.guide_emb_fn = nn.Sequential(*[
            nn.Linear(2*self.qdim, self.qdim), # W_g in Eq. (4)
            nn.ReLU()
        ])
        
        # Cross Attention으로 변경
        self.att_fn = CrossAttention(qdim, nheads=8, dropout=0.1)

    def forward(self, q_feats, w_feats, w_mask=None):
        """ extract N (=nse) semantic entity features from query
        Args:
            q_feats: sentence-level feature; [B,qdim]
            w_feats: phrase-level features; [B,L,qdim]
            w_mask: mask for effective phrases; [B,L]
        Returns:
            se_feats: semantic entity features; [B,N,qdim]
            se_attw: attention weight over phrases; [B,N,L]
        """
        q_feats = q_feats.squeeze(1)
        B = w_feats.size(0)
        prev_se = w_feats.new_zeros(B, self.qdim)
        se_feats, se_attw = [], []
        
        # compute semantic entity features sequentially
        for n in range(self.nse):
            # perform Eq. (4)
            q_n = self.global_emb_fn[n](q_feats) # [B,qdim] -> [B,qdim]
            g_n = self.guide_emb_fn(torch.cat([q_n, prev_se], dim=1)) # [B,2*qdim] -> [B,qdim]
            
            # Cross Attention 적용
            # guide vector를 query로, word features를 key와 value로 사용
            g_n = g_n.unsqueeze(1)  # [B,1,qdim]
            att_f, att_w = self.att_fn(g_n, w_feats, w_mask)  # att_f: [B,1,qdim], att_w: [B,1,L]
            
            prev_se = att_f.squeeze(1)  # [B,qdim]
            se_feats.append(prev_se)
            se_attw.append(att_w.squeeze(1))  # [B,L]

        return torch.stack(se_feats, dim=1), torch.stack(se_attw, dim=1)
    

class Phrase_Generate(nn.Module):
    def __init__(self, num_phrase, hdim, num_heads, drop_p, num_layers):
        super(Phrase_Generate, self).__init__()
        self.num_layers = num_layers
        self.phrase_att = nn.ModuleList([SlotAttention(num_phrase, hdim, num_heads, drop_p) for _ in range(num_layers)])
        self.sqan = SequentialQueryAttention(num_phrase, hdim)
        self.pos = PositionEmbeddingSine(hdim)
        self.eos_slot = nn.Parameter(torch.randn(1, 1, hdim)) # [1, 1, C]
        # phrase_weight 계산용
        self.eos_proj = nn.Linear(hdim, hdim)
        self.phrase_proj = nn.Linear(hdim, hdim)

    def forward(self, txt_emb, txt_mask):
        B, L, C = txt_emb.shape
        stc_emb, word_emb = torch.split(txt_emb, [1, L-1], dim=1)
        word_mask = txt_mask[:, 1:]
        word_pos = self.pos(word_emb, word_mask)
        word_pe = word_emb + word_pos

        phrase_slot, phrase_attn = self.sqan(stc_emb, word_pe, word_mask)

        slot_sim_lst = []
        eos_slot = self.eos_slot.expand(B, 1, C)  # [B, 1, C]
        for i in range(self.num_layers):
            phrase_slot, eos_slot, slot_sim = self.phrase_att[i](word_pe, word_mask, phrase_slot, eos_slot)
            slot_sim_lst.append(slot_sim)

        slot_sim = torch.stack(slot_sim_lst, dim=1).mean(dim=1)

        #phrase weight 계산
        eos_slot = self.eos_proj(eos_slot)
        phrase_slot = self.phrase_proj(phrase_slot)
        phrase_weight = torch.softmax(torch.bmm(eos_slot, phrase_slot.transpose(1, 2)), dim=1)

        return phrase_slot, phrase_attn, slot_sim, eos_slot, phrase_weight

class SlotAttention(nn.Module):
    def __init__(self, num_phrase, hdim, num_heads, drop_p=0.1):
        super(SlotAttention, self).__init__()
        self.nh = num_heads
        self.N = num_phrase
        self.C = hdim
        self.dropout = nn.Dropout(drop_p)
        self.dropout_s = nn.Dropout(drop_p)
        self.norm_s = nn.LayerNorm(hdim)
        self.norm = nn.LayerNorm(hdim)

        self.q_proj = nn.Linear(hdim, hdim)
        self.k_proj = nn.Linear(hdim, hdim)
        self.v_proj = nn.Linear(hdim, hdim)
        self.slot_att = nn.MultiheadAttention(hdim, self.nh, batch_first=True, dropout=drop_p)

        self.self_att = nn.MultiheadAttention(hdim, self.nh, batch_first=True, dropout=drop_p)
        self.linear1 = nn.Linear(hdim, hdim*4)
        self.linear2 = nn.Linear(hdim*4, hdim)
        self.norm1 = nn.LayerNorm(hdim)
        self.act = nn.ReLU()
        self.dropout1 = nn.Dropout(drop_p)

    def forward(self, txt_feat, txt_mask, phrase_slot, eos_slot):
        """
        Inputs:
            txt_feat: [B, L, C]
            txt_mask: [B, L]
            phrase_slot: [B, N, C]
            eos_slot: [B, 1, C]
        Returns:
            phrase_slot: [B, N, C]
            eos_slot: [B, 1, C]
            slot_sim: [B, N, N] (eos 제외)
        """
        B, N, C = phrase_slot.shape
        # 1. Cross Attention (Slot <-> Word)
        Q = self.q_proj(phrase_slot)
        K = self.k_proj(txt_feat)
        V = self.v_proj(txt_feat)
        slot_update, slot_sim = self.slot_att(Q, K, V, key_padding_mask=~(txt_mask.bool())) # [B, N, C], [B, N, L]
        slot_update = self.dropout(slot_update)
        phrase_slot = self.norm(slot_update + phrase_slot)

        # 2. Self-Attention (Slot+EOS)
        slots = torch.cat([eos_slot, phrase_slot], dim=1)  # [B, N+1, C]
        slots_sa, _ = self.self_att(slots, slots, slots)  # [B, N+1, C]
        slots = self.norm1(slots + self.dropout_s(slots_sa))

        # 3. FFN + Residual
        slots_ffn = self.linear2(self.act(self.linear1(slots)))
        slots = slots + self.dropout1(slots_ffn)
        slots = self.norm1(slots)

        # 4. 분리
        eos_slot = slots[:, 0:1, :]
        phrase_slot = slots[:, 1:, :]
        if slot_sim is not None:
            slot_sim = slot_sim[:, 1:, 1:]  # [B, N, N]

        return phrase_slot, eos_slot, slot_sim

class GlobalAggregate(nn.Module):
    def __init__(self, hdim):
        super(GlobalAggregate, self).__init__()
        self.hdim = hdim
        self.norm = nn.LayerNorm(hdim)
        self.act = nn.ReLU()
        self.dropout = nn.Dropout(0.1)
        
        self.linear = nn.Sequential(
            nn.Linear(hdim, hdim),
            nn.LayerNorm(hdim),
            nn.ReLU(),
        )
    def forward(self, context, phrase_weight):
        """
        context: [B, T, N, C]
        phrase_weight: [B, 1, N]
        """
        context = context * phrase_weight.unsqueeze(-1)
        context = context.sum(dim=2)

        context_agg = self.linear(context) + context

        return context_agg

    
class PhraseContextLayer(nn.Module):
    def __init__(self, hdim, nheads, dropout=0.1):
        super(PhraseContextLayer, self).__init__()
        # T-axis self-attention
        self.t_att = TransformerEncoderLayer(
            d_model=hdim,
            nhead=nheads,
            dim_feedforward=hdim*4,
            dropout=dropout,
            activation="relu",
            normalize_before=False,
            batch_first=True
        )
        
    def forward(self, context_emb, vid_mask):
        """
        context_emb: [B*N, T, C]
        """
        # T-axis self-attention
        context_emb = self.t_att(context_emb, src_key_padding_mask=~(vid_mask.bool())) # [B*N, T, C]
        
        return context_emb


class Phrase_Context(nn.Module):
    def __init__(self, hdim, num_layers, nheads, dropout=0.1, num_phrase=3, rank=32, t_kernels=(1,3,5)):
        super(Phrase_Context, self).__init__()
        self.hdim = hdim
        self.num_layers = num_layers
        self.layers = nn.ModuleList([PhraseContextLayer(hdim, nheads, dropout) for _ in range(num_layers)])
        self.dropout = nn.Dropout(dropout)
        self.rank = rank


        self.product = HadamardProduct(hdim, hdim, hdim)
        self.pos = PositionEmbeddingSine(hdim)
        self.local_context = GlobalAggregate(hdim)
    def forward(self, phrase_slot, phrase_weight, vid_feat, vid_mask):
        """
        Args:
            phrase_slot: [B, N, C] phrase slots
            vid_feat: [B, T, C] video-level features
        Returns:
            updated_phrase: [B, T, N, C]
        """
        B, T, C = vid_feat.shape
        N = phrase_slot.shape[1]
        
        context_emb = self.product([phrase_slot, vid_feat]) # [ B, N, T, C]
        context_emb_out = context_emb
        context_emb = rearrange(context_emb, 'b n t c -> (b n) t c') # [B*N, T, C]
        
        vid_mask = repeat(vid_mask, 'b t -> (b n) t', n=N) # [B*N, T]
        pos = self.pos(context_emb, vid_mask) # [B*N, T, C]
        context_emb = context_emb + pos
        
        for layer in self.layers:
            context_emb = layer(context_emb, vid_mask)
        context_emb = rearrange(context_emb, '(b n) t c -> b t n c', b=B, n=N)
        #context_emb_out = context_emb.permute(0, 2, 1, 3) # [B, N, T, C]
        context_agg = self.local_context(context_emb, phrase_weight)
        
        return context_agg, context_emb_out

class HadamardProduct(nn.Module):
    def __init__(self, idim_1, idim_2, hdim):
        super(HadamardProduct, self).__init__()

        self.fc_1 = nn.Linear(idim_1, hdim)
        self.fc_2 = nn.Linear(idim_2, hdim)
        self.fc_3 = nn.Linear(hdim, hdim)
        self.norm = nn.LayerNorm(hdim)
        self.norm1 = nn.LayerNorm(hdim)
    def forward(self, inp):
        """
        Args:
            inp0: Phrase [B,N,C]
            inp1: Vid [B,T,C]
        """
        x1, x2 = inp[0], inp[1]
        x1 = torch.relu(self.fc_1(x1)).unsqueeze(2) # [B, N, 1, hdim]
        x2 = torch.relu(self.fc_2(x2)).unsqueeze(1) # [B, 1, T, hdim]
        x = self.norm(x1 * x2) # [B, N, T, hdim]
        return torch.relu(self.norm1(self.fc_3(x))) # [B, N, T, hdim]
    
class SelfAttention(nn.Module):
    def __init__(self, hdim, nheads, dropout=0.1):
        super(SelfAttention, self).__init__()
        self.hdim = hdim
        self.nheads = nheads
        self.att = nn.MultiheadAttention(hdim, nheads, batch_first=True, dropout=dropout)
        self.q_proj = nn.Linear(hdim, hdim)
        self.k_proj = nn.Linear(hdim, hdim)
        self.v_proj = nn.Linear(hdim, hdim)
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(hdim)
        
    def forward(self, x, mask=None):
        """
        Args:
            x: [B, L, C]
            mask: [B, L]
        """
        B, L, C = x.shape
        q = self.q_proj(x) # [B, L, C]
        k = self.k_proj(x) # [B, L, C]
        v = self.v_proj(x) # [B, L, C]

        if mask is None:
            update, attn = self.att(q, k, v)
        else:
            update, attn = self.att(q, k, v, key_padding_mask=~(mask.bool()))
        update = self.dropout(update)
        x = self.norm(x + update)
        return x, attn

    
class T_SA_layer(nn.Module):
    def __init__(self, hdim, nheads, dropout=0.1):
        super(T_SA_layer, self).__init__()
        self.t_att = SelfAttention(hdim, nheads, dropout=dropout)
        self.linear = nn.Linear(hdim, hdim)
        self.act = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(hdim)
        self.norm1 = nn.LayerNorm(hdim)
    def forward(self, src_emb, mask=None):
        """
        src_emb: [B, T, C]
        """
        # T-axis self-attention
        src_emb, _ = self.t_att(src_emb, mask) # [B*N, T, C]
        update = self.dropout(self.act(self.linear(src_emb)))
        src_emb = self.norm(src_emb + update)

        return src_emb

class T_SA(nn.Module):
    def __init__(self, hdim, nheads, dropout=0.1, num_layers=2):
        super(T_SA, self).__init__()
        self.hdim = hdim
        self.num_layers = num_layers
        
        # TransformerEncoderLayer를 사용하여 레이어 구성
        encoder_layer = TransformerEncoderLayer(
            d_model=hdim,
            nhead=nheads,
            dim_feedforward=hdim*4,
            dropout=dropout,
            activation="relu",
            normalize_before=False,
            batch_first=True
        )
        self.encoder = TransformerEncoder(encoder_layer, num_layers=num_layers)

    def forward(self, src_emb, mask=None):
        """
        Args:
            src_emb: [B, T, C]
        Returns:
            updated_phrase: [B, T, C]
        """
        if mask is not None:
            src_emb = self.encoder(src_emb, src_key_padding_mask=~(mask.bool()))
        else:
            src_emb = self.encoder(src_emb)
        return src_emb

    
class Saliency_proj(nn.Module):
    def __init__(self, hdim):
        super(Saliency_proj, self).__init__()
        self.proj1 = nn.Linear(hdim, hdim)
        self.proj2 = nn.Linear(hdim, hdim)
        self.hdim = hdim
    def forward(self, x):
        """
        Args:
            x: [B, T, C]
        """
        B, T, C = x.shape
        x1 = self.proj1(x)
        x_global = x.mean(1)
        x2 = self.proj2(x_global).unsqueeze(1)
        intermediate_result = x1 * x2
        saliency_scores = torch.sum(intermediate_result, dim=-1) / self.hdim ** 0.5

        return saliency_scores